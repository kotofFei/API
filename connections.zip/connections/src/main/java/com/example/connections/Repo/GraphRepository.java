package com.example.connections.Repo;


import com.example.connections.Models.Car;
import com.example.connections.Models.Graph;
import org.springframework.data.repository.CrudRepository;

public interface GraphRepository extends CrudRepository<Graph, Long> {
    Graph findByGraph(String graph);
}
