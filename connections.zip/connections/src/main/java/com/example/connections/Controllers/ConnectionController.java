package com.example.connections.Controllers;

import com.example.connections.Models.*;
import com.example.connections.Repo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.constraints.PositiveOrZero;
import java.util.List;

@Controller
public class ConnectionController {
    @Autowired
    private PeopleRepository peopleRepository;
    @Autowired
    private CarRepository carRepository;
    @Autowired
    private WorkerRepository workerRepository;
    @Autowired
    private GraphRepository graphRepository;
    @Autowired
    private CityRepository cityRepository;
    @Autowired
    private ShopRepository shopRepository;

    @GetMapping("/")
    public String connectionMain(Model model) {
        return "main-view";
    }

    @GetMapping("/onetoone")
    public String peopleView(Model model) {
        Iterable<People> people = peopleRepository.findAll();
        Iterable<Car> car = carRepository.findAll();
        model.addAttribute("people", people);
        model.addAttribute("car", car);
        return "OneToOne/onetoone-view";
    }

    @GetMapping("/people/add")
    public String peopleAdd(Model model) {
        Iterable<Car> car = carRepository.findAll();
        model.addAttribute("car", car);
        return "OneToOne/people-add";
    }

    @PostMapping("/people/add")
    public String peopleAdd(@RequestParam String fio,
                            @RequestParam String carNum,
                            Model model) {
        Car car = carRepository.findByCarNum(carNum);
        People people = new People(fio, car);
        peopleRepository.save(people);
        return "redirect:/onetoone";
    }

    @GetMapping("/car/add")
    public String carAdd(Model model) {
        return "OneToOne/car-add";
    }

    @PostMapping("/car/add")
    public String carAdd(@RequestParam String carNum,
                         Model model) {
        Car car = new Car(carNum);
        carRepository.save(car);
        return "redirect:/onetoone";
    }

    @GetMapping("/onetomany")
    public String workerView(Model model) {
        Iterable<Worker> worker = workerRepository.findAll();
        Iterable<Graph> graph = graphRepository.findAll();
        model.addAttribute("worker", worker);
        model.addAttribute("graph", graph);
        return "OneToMany/onetomany-view";
    }

    @GetMapping("/worker/add")
    public String workerAdd(Model model) {
        Iterable<Graph> graph = graphRepository.findAll();
        model.addAttribute("graph", graph);
        return "OneToMany/worker-add";
    }

    @PostMapping("/worker/add")
    public String workerAdd(@RequestParam String fio,
                            @RequestParam String graph,
                            Model model) {
        Graph graphs = graphRepository.findByGraph(graph);
        Worker worker = new Worker(fio, graphs);
        workerRepository.save(worker);
        return "redirect:/onetomany";
    }

    @GetMapping("/graph/add")
    public String graphAdd(Model model) {
        return "OneToMany/graph-add";
    }

    @PostMapping("/graph/add")
    public String graphAdd(@RequestParam String graph,
                           Model model) {
        Graph graphs = new Graph(graph);
        graphRepository.save(graphs);
        return "redirect:/onetomany";
    }

    @GetMapping("/manytomany")
    public String manytomanyView(Model model) {
        Iterable<City> cities = cityRepository.findAll();
        Iterable<Shop> shops = shopRepository.findAll();
        model.addAttribute("city", cities);
        model.addAttribute("shop", shops);
        return "ManyToMany/manytomany-view";
    }

    @PostMapping("/manytomany")
    public String mamytomanyAdd(@RequestParam String city,
                                @RequestParam String shop,
                                Model model){
        City city1 = cityRepository.findByName(city);
        Shop shop1 = shopRepository.findByName(shop);
        city1.getShops().add(shop1);
        cityRepository.save(city1);
        return "redirect:/manytomany";
    }

    @GetMapping("/city/add")
    public String cityAdd(Model model) {

        return "ManyToMany/city-add";
    }

    @PostMapping("/city/add")
    public String cityAdd(@RequestParam String name,
                            Model model) {
        City city = new City(name);
        cityRepository.save(city);
        return "redirect:/manytomany";
    }

    @GetMapping("/shop/add")
    public String shopAdd(Model model) {

        return "ManyToMany/shop-add";
    }

    @PostMapping("/shop/add")
    public String shopAdd(@RequestParam String name,
                           Model model) {
        Shop shop = new Shop(name);
        shopRepository.save(shop);
        return "redirect:/manytomany";
    }
}
