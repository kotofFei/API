package com.example.connections.Models;

import javax.persistence.*;
import java.util.Collection;

@Entity
@Table(name = "graph")
public class Graph {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String graph;
    @OneToMany(mappedBy = "graph", fetch = FetchType.EAGER)
    private Collection<Worker> workers;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getGraph() {
        return graph;
    }

    public void setGraph(String graph) {
        this.graph = graph;
    }

    public Collection<Worker> getWorkers() {
        return workers;
    }

    public void setWorkers(Collection<Worker> workers) {
        this.workers = workers;
    }

    public Graph(String graph) {
        this.graph = graph;
        this.workers = workers;
    }

    public Graph() {

    }
}
