package com.example.connections.Models;

import javax.persistence.*;

@Entity
@Table(name = "worker")
public class Worker {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String fio;

    @ManyToOne(optional = false, cascade = CascadeType.ALL)
    @JoinColumn(name="graph_id")
    private Graph graph;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFio() {
        return fio;
    }

    public void setFio(String fio) {
        this.fio = fio;
    }

    public Graph getGraph() {
        return graph;
    }

    public void setGraph(Graph graph) {
        this.graph = graph;
    }

    public Worker(String fio, Graph graph) {
        this.fio = fio;
        this.graph = graph;
    }

    public Worker() {
    }
}
