package com.example.connections.Repo;


import com.example.connections.Models.City;
import com.example.connections.Models.Shop;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ShopRepository extends CrudRepository<Shop, Long> {
    Shop findByName(String name);
}
