package com.example.project7.models;

public enum Role {
    USER;
}
